# TrackLive 📡
Sistema de rastreamento em tempo real via WebSocket + GPS nativo.

## Estrutura
```
tracker/
├── server.js          # Servidor Node.js + WebSocket
├── package.json
├── render.yaml        # Deploy no Render
└── public/
    ├── index.html     # Página inicial (gerar link)
    ├── track.html     # Tracker (quem compartilha)
    └── view.html      # Viewer (mapa ao vivo)
```

## Rodar Localmente

### Pré-requisitos
- Node.js 18+

### Instalação
```bash
cd tracker
npm install
node server.js
```

Acesse: http://localhost:3000

### Fluxo
1. **Usuário A** abre http://localhost:3000 → clica "Gerar Link Único"
2. **Usuário A** abre o "Mapa de visualização" em outra aba (ou envia para alguém)
3. **Usuário B** recebe o link de rastreamento (track.html?s=ID), abre e aceita compartilhar
4. A localização aparece em tempo real no mapa do Usuário A

## Deploy no Render

### Via render.yaml (recomendado)
1. Faça push do projeto para GitHub/GitLab
2. Acesse https://render.com → New → Blueprint
3. Aponte para seu repositório
4. Render detecta o `render.yaml` automaticamente
5. Deploy automático em ~2 minutos

### Manual
1. New → Web Service
2. Connect seu repositório
3. Build Command: `npm install`
4. Start Command: `node server.js`
5. Environment: Node
6. Plano: Free (funciona)

### HTTPS/WSS no Render
Render fornece HTTPS automaticamente. O código detecta `wss://` automaticamente quando em HTTPS.

## Tecnologias
- **Backend**: Node.js + Express + ws (WebSocket)
- **Frontend**: HTML/CSS/JS puro
- **Mapa**: Leaflet.js + OpenStreetMap
- **GPS**: navigator.geolocation.watchPosition (alta precisão)
- **Bateria**: Battery Status API
- **Memória**: in-memory (sem banco de dados)

## Notas de Segurança
- Links expiram em 1 hora
- Nenhum dado é persistido em disco
- Sessões limpas automaticamente da memória
- GPS nunca usa localização por IP
